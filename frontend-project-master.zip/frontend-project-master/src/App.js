import React from 'react';
import MainComponent from './MainComponenet';

function App() {
  return (
    <userContext>
      <MainComponent></MainComponent>
    </userContext>
  );
}
export default App;
